/* =====================================================
   BASIC CALCULATOR
===================================================== */

let current = "";
let previous = "";
let operator = null;

let memory = 0;

let history =
    JSON.parse(
        localStorage.getItem("smartcalc-history")
    ) || [];


const $ = id =>
    document.getElementById(id);


/* DISPLAY */

function render() {

    $("current").textContent =
        current || "0";

    $("previous").textContent =
        operator
            ? `${previous} ${operator}`
            : "";
}


/* NUMBER */

function append(value) {

    if (value === "%") {

        if (current) {

            current =
                (
                    parseFloat(current) / 100
                ).toString();

        }

        render();

        return;
    }


    if (
        value === "." &&
        current.includes(".")
    ) {

        return;
    }


    if (
        value === "." &&
        !current
    ) {

        current = "0";
    }


    current += value;

    render();
}


/* CLEAR */

function clearCalc() {

    current = "";

    previous = "";

    operator = null;

    render();
}


/* DELETE */

function backspace() {

    current =
        current.slice(0, -1);

    render();
}


/* PLUS / MINUS */

function toggleSign() {

    if (!current) return;

    current =
        (
            parseFloat(current) * -1
        ).toString();

    render();
}


/* OPERATOR */

function setOperator(op) {

    if (
        !current &&
        !previous
    ) {

        return;
    }


    if (
        previous &&
        current
    ) {

        calculate();
    }


    operator = op;

    previous = current;

    current = "";

    render();
}


/* CALCULATE */

function calculate() {

    if (
        !previous ||
        !current ||
        !operator
    ) {

        return;
    }


    let a =
        parseFloat(previous);

    let b =
        parseFloat(current);

    let result;


    switch (operator) {

        case "+":

            result = a + b;

            break;


        case "-":

            result = a - b;

            break;


        case "*":

            result = a * b;

            break;


        case "/":

            if (b === 0) {

                current = "Error";

                previous = "";

                operator = null;

                render();

                return;
            }

            result = a / b;

            break;

    }


    result =
        Math.round(
            (result + Number.EPSILON)
            * 1000000000000
        ) / 1000000000000;


    addHistory(
        `${previous} ${operator} ${current} = ${result}`
    );


    current =
        String(result);

    previous = "";

    operator = null;

    render();
}


/* =====================================================
   HISTORY
===================================================== */

function addHistory(value) {

    history.push(value);


    history =
        history.slice(-50);


    localStorage.setItem(
        "smartcalc-history",
        JSON.stringify(history)
    );
}


function renderHistory() {

    const list =
        $("historyList");


    if (!history.length) {

        list.innerHTML =
            "<p>No calculations yet.</p>";

        return;
    }


    list.innerHTML = "";


    history
        .slice()
        .reverse()
        .forEach(item => {

            const div =
                document.createElement(
                    "div"
                );

            div.className =
                "history-item";

            div.textContent =
                item;

            list.appendChild(div);

        });
}


function toggleHistory() {

    renderHistory();


    $("historyPanel")
        .classList.toggle("open");
}


function clearHistory() {

    history = [];


    localStorage.removeItem(
        "smartcalc-history"
    );


    renderHistory();
}


/* =====================================================
   SIDEBAR
===================================================== */

function toggleSidebar() {

    $("sidebar")
        .classList.toggle("open");
}


/* =====================================================
   SCIENTIFIC
===================================================== */

function scientific(type) {

    let x =
        parseFloat(current);


    if (type === "pi") {

        current =
            String(Math.PI);
    }


    else if (type === "e") {

        current =
            String(Math.E);
    }


    else if (!Number.isFinite(x)) {

        return;
    }


    else if (type === "sin") {

        current =
            String(Math.sin(x));
    }


    else if (type === "cos") {

        current =
            String(Math.cos(x));
    }


    else if (type === "tan") {

        current =
            String(Math.tan(x));
    }


    else if (type === "sqrt") {

        current =
            x >= 0
                ? String(Math.sqrt(x))
                : "Error";
    }


    else if (type === "log") {

        current =
            x > 0
                ? String(Math.log10(x))
                : "Error";
    }


    else if (type === "ln") {

        current =
            x > 0
                ? String(Math.log(x))
                : "Error";
    }


    else if (type === "square") {

        current =
            String(x * x);
    }


    else if (type === "cube") {

        current =
            String(x * x * x);
    }


    render();
}


/* =====================================================
   MEMORY
===================================================== */

function memoryClear() {

    memory = 0;
}


function memoryRecall() {

    current =
        String(memory);

    render();
}


function memoryAdd() {

    memory +=
        parseFloat(current || 0);
}


function memorySubtract() {

    memory -=
        parseFloat(current || 0);
}


function memoryStore() {

    memory =
        parseFloat(current || 0);
}


/* =====================================================
   KEYBOARD SUPPORT
===================================================== */

document.addEventListener(
    "keydown",
    function(event) {

        if (
            $("calculatorView")
                .classList.contains("hidden")
        ) {

            return;
        }


        if (
            /[0-9]/.test(event.key) ||
            event.key === "."
        ) {

            append(event.key);
        }


        else if (
            ["+", "-", "*", "/"]
                .includes(event.key)
        ) {

            setOperator(event.key);
        }


        else if (
            event.key === "Enter" ||
            event.key === "="
        ) {

            calculate();
        }


        else if (
            event.key === "Backspace"
        ) {

            backspace();
        }


        else if (
            event.key === "Escape"
        ) {

            clearCalc();
        }

    }
);


/* =====================================================
   MODE SWITCHING
===================================================== */

document
    .querySelectorAll(
        ".nav[data-mode]"
    )
    .forEach(button => {

        button.addEventListener(
            "click",
            function() {

                const mode =
                    this.dataset.mode;


                document
                    .querySelectorAll(
                        ".nav[data-mode]"
                    )
                    .forEach(btn =>
                        btn.classList
                            .remove("active")
                    );


                this.classList
                    .add("active");


                switchMode(mode);


                if (window.innerWidth < 700) {

                    $("sidebar")
                        .classList
                        .remove("open");

                }

            }
        );

    });


function switchMode(mode) {

    $("calculatorView")
        .classList
        .toggle(
            "hidden",
            ![
                "standard",
                "scientific"
            ].includes(mode)
        );


    $("graphingView")
        .classList
        .toggle(
            "hidden",
            mode !== "graphing"
        );


    $("programmerView")
        .classList
        .toggle(
            "hidden",
            mode !== "programmer"
        );


    $("dateView")
        .classList
        .toggle(
            "hidden",
            mode !== "date"
        );


    $("converterView")
        .classList
        .toggle(
            "hidden",
            ![
                "currency",
                "volume",
                "length"
            ].includes(mode)
        );


    $("scientificKeys")
        .classList
        .toggle(
            "hidden",
            mode !== "scientific"
        );


    if (mode === "scientific") {

        $("modeLabel")
            .textContent =
            "Scientific";

    }


    else {

        $("modeLabel")
            .textContent =
            "Standard";

    }


    if (mode === "graphing") {

        $("pageTitle")
            .textContent =
            "Graphing";

    }


    else if (mode === "programmer") {

        $("pageTitle")
            .textContent =
            "Programmer";

    }


    else if (mode === "date") {

        $("pageTitle")
            .textContent =
            "Date calculation";

    }


    else if (
        [
            "currency",
            "volume",
            "length"
        ].includes(mode)
    ) {

        $("pageTitle")
            .textContent =
            "Converter";


        setConverter(mode);

    }


    else {

        $("pageTitle")
            .textContent =
            "Calculator";

    }

}


/* =====================================================
   GRAPHING CALCULATOR
===================================================== */

function drawGraph() {

    const canvas =
        $("graphCanvas");

    const ctx =
        canvas.getContext("2d");


    const expression =
        $("functionInput")
            .value
            .trim();


    ctx.clearRect(
        0,
        0,
        canvas.width,
        canvas.height
    );


    const centerX =
        canvas.width / 2;

    const centerY =
        canvas.height / 2;

    const scale = 35;


    /* GRID */

    ctx.strokeStyle = "#444";

    ctx.lineWidth = 1;


    for (
        let x = 0;
        x < canvas.width;
        x += scale
    ) {

        ctx.beginPath();

        ctx.moveTo(x, 0);

        ctx.lineTo(
            x,
            canvas.height
        );

        ctx.stroke();
    }


    for (
        let y = 0;
        y < canvas.height;
        y += scale
    ) {

        ctx.beginPath();

        ctx.moveTo(0, y);

        ctx.lineTo(
            canvas.width,
            y
        );

        ctx.stroke();
    }


    /* AXES */

    ctx.strokeStyle = "#aaa";

    ctx.beginPath();

    ctx.moveTo(
        centerX,
        0
    );

    ctx.lineTo(
        centerX,
        canvas.height
    );

    ctx.moveTo(
        0,
        centerY
    );

    ctx.lineTo(
        canvas.width,
        centerY
    );

    ctx.stroke();


    /* CONVERT FUNCTION */

    let fn =
        expression

            .replace(
                /\^/g,
                "**"
            )

            .replace(
                /\bpi\b/gi,
                "Math.PI"
            )

            .replace(
                /\be\b/g,
                "Math.E"
            )

            .replace(
                /\bsin\b/g,
                "Math.sin"
            )

            .replace(
                /\bcos\b/g,
                "Math.cos"
            )

            .replace(
                /\btan\b/g,
                "Math.tan"
            )

            .replace(
                /\bsqrt\b/g,
                "Math.sqrt"
            )

            .replace(
                /\blog\b/g,
                "Math.log10"
            )

            .replace(
                /\bln\b/g,
                "Math.log"
            )

            .replace(
                /\babs\b/g,
                "Math.abs"
            );


    try {

        const functionToPlot =
            Function(
                "x",
                "return " + fn
            );


        ctx.strokeStyle =
            "#35e879";

        ctx.lineWidth = 2;

        ctx.beginPath();


        let firstPoint = true;


        for (
            let px = 0;
            px < canvas.width;
            px++
        ) {

            let x =
                (px - centerX)
                / scale;


            let y =
                functionToPlot(x);


            if (
                !Number.isFinite(y) ||
                Math.abs(y) > 20
            ) {

                firstPoint = true;

                continue;
            }


            let py =
                centerY -
                y * scale;


            if (firstPoint) {

                ctx.moveTo(
                    px,
                    py
                );

                firstPoint = false;

            }

            else {

                ctx.lineTo(
                    px,
                    py
                );

            }

        }


        ctx.stroke();

    }

    catch (error) {

        toast(
            "Invalid graph expression"
        );

    }

}


function clearGraph() {

    const canvas =
        $("graphCanvas");


    canvas
        .getContext("2d")
        .clearRect(
            0,
            0,
            canvas.width,
            canvas.height
        );
}


/* =====================================================
   PROGRAMMER CALCULATOR
===================================================== */

function updateProgrammer() {

    let value =
        $("programmerInput")
            .value || "0";


    let base =
        parseInt(
            $("programmerBase").value
        );


    let number =
        parseInt(value, base);


    if (isNaN(number)) {

        number = 0;

    }


    $("binOut")
        .textContent =
        (number >>> 0)
            .toString(2);


    $("octOut")
        .textContent =
        (number >>> 0)
            .toString(8);


    $("decOut")
        .textContent =
        String(number);


    $("hexOut")
        .textContent =
        (number >>> 0)
            .toString(16)
            .toUpperCase();

}


$("programmerInput")
    .addEventListener(
        "input",
        updateProgrammer
    );


$("programmerBase")
    .addEventListener(
        "change",
        updateProgrammer
    );


function bitOp(operation) {

    let base =
        parseInt(
            $("programmerBase").value
        );


    let number =
        parseInt(
            $("programmerInput").value,
            base
        );


    if (isNaN(number)) {

        number = 0;

    }


    let result;


    switch (operation) {

        case "and":

            result =
                number & 1;

            break;


        case "or":

            result =
                number | 1;

            break;


        case "xor":

            result =
                number ^ 1;

            break;


        case "not":

            result =
                ~number;

            break;

    }


    $("bitResult")
        .textContent =
        `Result: ${result} | HEX: ${(result >>> 0)
        .toString(16)
        .toUpperCase()} | BIN: ${(result >>> 0)
        .toString(2)}`;

}


/* =====================================================
   DATE CALCULATOR
===================================================== */

const today =
    new Date();


$("startDate")
    .valueAsDate =
    today;


$("endDate")
    .valueAsDate =
    today;


$("addDate")
    .valueAsDate =
    today;


/* DATE DIFFERENCE */

function calculateDateDifference() {

    const start =
        new Date(
            $("startDate").value
        );


    const end =
        new Date(
            $("endDate").value
        );


    const difference =
        Math.abs(
            end - start
        );


    const days =
        Math.round(
            difference /
            86400000
        );


    const weeks =
        Math.floor(
            days / 7
        );


    const remainingDays =
        days % 7;


    $("dateResult")
        .textContent =
        `${days} days = ${weeks} weeks and ${remainingDays} days`;
}


/* ADD DAYS */

function addDays() {

    const date =
        new Date(
            $("addDate").value
        );


    const days =
        parseInt(
            $("daysToAdd").value
        ) || 0;


    date.setDate(
        date.getDate() + days
    );


    $("addDateResult")
        .textContent =
        date.toLocaleDateString(
            undefined,
            {
                year: "numeric",
                month: "long",
                day: "numeric"
            }
        );
}


/* =====================================================
   CONVERTERS
===================================================== */


/* VOLUME */

const volumeUnits = {

    ml: 1,

    liter: 1000,

    cm3: 1,

    m3: 1000000,

    gallon: 3785.411784

};


/* LENGTH */

const lengthUnits = {

    mm: 1,

    cm: 10,

    meter: 1000,

    km: 1000000,

    inch: 25.4,

    foot: 304.8,

    yard: 914.4,

    mile: 1609344

};


/* CURRENCIES */

const currencies = {

    USD: 1,

    EUR: 0.86,

    INR: 83.5,

    GBP: 0.74,

    JPY: 150,

    CAD: 1.37,

    AUD: 1.52

};


/* UNIT LABELS */

const volumeLabels = {

    ml: "Milliliter",

    liter: "Liter",

    cm3: "Cubic Centimeter",

    m3: "Cubic Meter",

    gallon: "Gallon"

};


const lengthLabels = {

    mm: "Millimeter",

    cm: "Centimeter",

    meter: "Meter",

    km: "Kilometer",

    inch: "Inch",

    foot: "Foot",

    yard: "Yard",

    mile: "Mile"

};


/* FILL SELECT */

function fillSelect(
    id,
    items
) {

    $(id).innerHTML = "";


    Object.entries(items)
        .forEach(
            ([key, value]) => {

                const option =
                    document.createElement(
                        "option"
                    );


                option.value =
                    key;


                option.textContent =
                    value;


                $(id)
                    .appendChild(option);

            }
        );

}


/* CURRENCY SELECTS */

fillSelect(
    "currencyFrom",
    currencies
);


fillSelect(
    "currencyTo",
    currencies
);


$("currencyTo")
    .value =
    "INR";


/* VOLUME SELECTS */

fillSelect(
    "volumeFrom",
    volumeLabels
);


fillSelect(
    "volumeTo",
    volumeLabels
);


/* LENGTH SELECTS */

fillSelect(
    "lengthFrom",
    lengthLabels
);


fillSelect(
    "lengthTo",
    lengthLabels
);


/* =====================================================
   CONVERTER TABS
===================================================== */

function setConverter(type) {

    document
        .querySelectorAll(
            ".converter-panel"
        )
        .forEach(panel => {

            panel.classList
                .add("hidden");

        });


    $(type + "Panel")
        .classList
        .remove("hidden");


    document
        .querySelectorAll(".tab")
        .forEach(tab => {

            tab.classList
                .toggle(
                    "active",
                    tab.dataset.converter
                    === type
                );

        });


    $("converterTitle")
        .textContent =
        type.charAt(0).toUpperCase()
        + type.slice(1)
        + " Converter";

}


/* TAB CLICK */

document
    .querySelectorAll(".tab")
    .forEach(tab => {

        tab.addEventListener(
            "click",
            function() {

                setConverter(
                    this.dataset.converter
                );

            }
        );

    });


/* =====================================================
   CURRENCY CONVERSION
===================================================== */

function convertCurrency() {

    const amount =
        parseFloat(
            $("currencyAmount").value
        ) || 0;


    const from =
        $("currencyFrom").value;


    const to =
        $("currencyTo").value;


    const result =
        amount /
        currencies[from] *
        currencies[to];


    $("currencyResult")
        .textContent =
        `${amount} ${from} = ${result.toFixed(4)} ${to}`;

}


/* =====================================================
   UNIT CONVERSION
===================================================== */

function convertUnit(type) {

    const value =
        parseFloat(
            $(
                type + "Value"
            ).value
        ) || 0;


    const from =
        $(
            type + "From"
        ).value;


    const to =
        $(
            type + "To"
        ).value;


    let units;

    let labels;


    if (type === "volume") {

        units =
            volumeUnits;

        labels =
            volumeLabels;

    }

    else {

        units =
            lengthUnits;

        labels =
            lengthLabels;

    }


    const result =
        value *
        units[from] /
        units[to];


    $(
        type + "Result"
    )
        .textContent =
        `${value} ${labels[from]} = ${result.toFixed(6)} ${labels[to]}`;

}


/* =====================================================
   ABOUT
===================================================== */

function showAbout() {

    toast(
        "SmartCalc - Frontend Calculator using HTML, CSS and JavaScript"
    );

}


/* =====================================================
   TOAST
===================================================== */

function toast(message) {

    const box =
        $("toast");


    box.textContent =
        message;


    box.classList
        .add("show");


    setTimeout(
        () => {

            box.classList
                .remove("show");

        },
        2500
    );

}


/* =====================================================
   START APPLICATION
===================================================== */

updateProgrammer();

switchMode(
    "standard"
);

render();