javascript
let currentImage = 0;

let visibleImages = [];


/* Open Lightbox */

function openLightbox(image) {

    // Get currently visible images
    visibleImages = Array.from(
        document.querySelectorAll(
            ".gallery-item:not([style*='display: none']) img"
        )
    );

    // Find clicked image
    currentImage = visibleImages.indexOf(image);

    // Show lightbox
    document.getElementById("lightbox").style.display = "flex";

    showImage();
}


/* Show Image */

function showImage() {

    document.getElementById("lightbox-img").src =
        visibleImages[currentImage].src;
}


/* Next / Previous */

function changeImage(direction) {

    currentImage += direction;


    // Go to last image
    if (currentImage < 0) {
        currentImage = visibleImages.length - 1;
    }


    // Go to first image
    if (currentImage >= visibleImages.length) {
        currentImage = 0;
    }


    showImage();
}


/* Close Lightbox */

function closeLightbox() {

    document.getElementById("lightbox").style.display = "none";
}


/* Filter Images */

function filterImages(category, button) {

    const items =
        document.querySelectorAll(".gallery-item");


    // Remove active class
    document.querySelectorAll(".filter-btn")
        .forEach(btn => {
            btn.classList.remove("active");
        });


    // Add active class
    button.classList.add("active");


    // Show / Hide images
    items.forEach(item => {

        if (
            category === "all" ||
            item.classList.contains(category)
        ) {

            item.style.display = "block";

        } else {

            item.style.display = "none";

        }

    });

}


/* Keyboard Navigation */

document.addEventListener("keydown", function(event) {

    // Escape = Close
    if (event.key === "Escape") {
        closeLightbox();
    }


    // Right Arrow = Next
    if (event.key === "ArrowRight") {

        if (visibleImages.length > 0) {
            changeImage(1);
        }

    }


    // Left Arrow = Previous
    if (event.key === "ArrowLeft") {

        if (visibleImages.length > 0) {
            changeImage(-1);
        }

    }

});
```
